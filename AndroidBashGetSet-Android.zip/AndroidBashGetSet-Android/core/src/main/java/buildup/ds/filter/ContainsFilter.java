package buildup.ds.filter;

public interface ContainsFilter extends Filter<String> {
    String getValue();
}
