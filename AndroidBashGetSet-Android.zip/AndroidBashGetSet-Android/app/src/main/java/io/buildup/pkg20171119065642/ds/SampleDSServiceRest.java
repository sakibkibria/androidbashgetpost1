
package io.buildup.pkg20171119065642.ds;
import java.util.List;
import retrofit.Callback;
import retrofit.http.GET;
import retrofit.http.Query;
import retrofit.http.POST;
import retrofit.http.Body;
import retrofit.http.DELETE;
import retrofit.http.Path;
import retrofit.http.PUT;
import retrofit.mime.TypedByteArray;
import retrofit.http.Part;
import retrofit.http.Multipart;

public interface SampleDSServiceRest{

	@GET("/app/5a112b29844e08040019a764/r/sampleDS")
	void querySampleDSItem(
		@Query("skip") String skip,
		@Query("limit") String limit,
		@Query("conditions") String conditions,
		@Query("sort") String sort,
		@Query("select") String select,
		@Query("populate") String populate,
		Callback<List<SampleDSItem>> cb);

	@GET("/app/5a112b29844e08040019a764/r/sampleDS/{id}")
	void getSampleDSItemById(@Path("id") String id, Callback<SampleDSItem> cb);

	@DELETE("/app/5a112b29844e08040019a764/r/sampleDS/{id}")
  void deleteSampleDSItemById(@Path("id") String id, Callback<SampleDSItem> cb);

  @POST("/app/5a112b29844e08040019a764/r/sampleDS/deleteByIds")
  void deleteByIds(@Body List<String> ids, Callback<List<SampleDSItem>> cb);

  @POST("/app/5a112b29844e08040019a764/r/sampleDS")
  void createSampleDSItem(@Body SampleDSItem item, Callback<SampleDSItem> cb);

  @PUT("/app/5a112b29844e08040019a764/r/sampleDS/{id}")
  void updateSampleDSItem(@Path("id") String id, @Body SampleDSItem item, Callback<SampleDSItem> cb);

  @GET("/app/5a112b29844e08040019a764/r/sampleDS")
  void distinct(
        @Query("distinct") String colName,
        @Query("conditions") String conditions,
        Callback<List<String>> cb);
    
    @Multipart
    @POST("/app/5a112b29844e08040019a764/r/sampleDS")
    void createSampleDSItem(
        @Part("data") SampleDSItem item,
        @Part("picture") TypedByteArray picture,
        Callback<SampleDSItem> cb);
    
    @Multipart
    @PUT("/app/5a112b29844e08040019a764/r/sampleDS/{id}")
    void updateSampleDSItem(
        @Path("id") String id,
        @Part("data") SampleDSItem item,
        @Part("picture") TypedByteArray picture,
        Callback<SampleDSItem> cb);
}
