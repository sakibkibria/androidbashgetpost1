

package io.buildup.pkg20171119065642.ui;

import android.os.Bundle;
import android.support.v4.app.Fragment;

import io.buildup.pkg20171119065642.R;

import buildup.ui.BaseListingActivity;
/**
 * FriendsMenuItem1Activity list activity
 */
public class FriendsMenuItem1Activity extends BaseListingActivity {

    @Override
    protected void onCreate(Bundle savedInstance) {
        super.onCreate(savedInstance);

        if(isTaskRoot()) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(false);
        } else {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        }
        
        setTitle(getString(R.string.friendsMenuItem1Activity));
    }

    @Override
    protected Class<? extends Fragment> getFragmentClass() {
        return FriendsMenuItem1Fragment.class;
    }

}
