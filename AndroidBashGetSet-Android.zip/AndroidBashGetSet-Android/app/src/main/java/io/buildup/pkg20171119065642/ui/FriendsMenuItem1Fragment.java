

package io.buildup.pkg20171119065642.ui;

import android.os.Bundle;

import io.buildup.pkg20171119065642.R;

import java.util.ArrayList;
import java.util.List;

import buildup.MenuItem;

import buildup.actions.StartActivityAction;
import buildup.util.Constants;

/**
 * FriendsMenuItem1Fragment menu fragment.
 */
public class FriendsMenuItem1Fragment extends buildup.ui.MenuFragment {
    /**
     * Default constructor
     */
    public FriendsMenuItem1Fragment(){
        super();
    }

    // Factory method
    public static FriendsMenuItem1Fragment newInstance(Bundle args) {
        FriendsMenuItem1Fragment fragment = new FriendsMenuItem1Fragment();

        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    // Menu Fragment interface
    @Override
    public List<MenuItem> getMenuItems() {
        ArrayList<MenuItem> items = new ArrayList<MenuItem>();
        items.add(new MenuItem()
            .setLabel("Friends")
            .setIcon(R.drawable.jpg_25004314e8caa903cf5eae5dd)
            .setAction(new StartActivityAction(FriendsActivity.class, Constants.DETAIL))
        );
        items.add(new MenuItem()
            .setLabel("Joe")
            .setIcon(R.drawable.png_icons8icons8129)
            .setAction(new StartActivityAction(JoeActivity.class, Constants.DETAIL))
        );
        return items;
    }

    @Override
    public int getLayout() {
        return R.layout.fragment_grid;
    }

    @Override
    public int getItemLayout() {
        return R.layout.friendsmenuitem1_item;
    }
}
