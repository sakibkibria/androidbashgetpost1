
package io.buildup.pkg20171119065642.ui;
import android.annotation.SuppressLint;
import android.os.Bundle;
import android.view.View;
import android.view.LayoutInflater;
import android.view.ViewGroup;
import io.buildup.pkg20171119065642.R;
import buildup.ds.Datasource;
import android.widget.ImageView;
import android.widget.TextView;
import buildup.ds.restds.AppNowDatasource;
import buildup.util.image.ImageLoader;
import buildup.util.image.PicassoImageLoader;
import buildup.util.StringUtils;
import java.net.URL;
import static buildup.util.image.ImageLoaderRequest.Builder.imageLoaderRequest;
import buildup.ds.SearchOptions;
import buildup.ds.filter.Filter;
import java.util.Arrays;
import io.buildup.pkg20171119065642.ds.SampleDSItem;
import io.buildup.pkg20171119065642.ds.SampleDS;

public class FriendsFragment extends buildup.ui.DetailFragment<SampleDSItem>  {

    private Datasource<SampleDSItem> datasource;
    private SearchOptions searchOptions;

    public static FriendsFragment newInstance(Bundle args){
        FriendsFragment card = new FriendsFragment();
        card.setArguments(args);

        return card;
    }

    public FriendsFragment(){
        super();
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        searchOptions = SearchOptions.Builder.searchOptions().build();
    }

    @Override
    public Datasource getDatasource() {
        if (datasource != null) {
            return datasource;
        }
        datasource = SampleDS.getInstance(searchOptions);
        return datasource;
    }

    // Bindings

    @Override
    protected int getLayout() {
        return R.layout.friends_custom;
    }

    @Override
    @SuppressLint("WrongViewCast")
    public void bindView(final SampleDSItem item, View view) {
        
        TextView view0 = (TextView) view.findViewById(R.id.view0);
        view0.setText((item.text1 != null ? item.text1 : ""));
        
        
        TextView view1 = (TextView) view.findViewById(R.id.view1);
        view1.setText((item.text2 != null ? item.text2 : ""));
        
        
        ImageView view2 = (ImageView) view.findViewById(R.id.view2);
        URL view2Media = ((AppNowDatasource) getDatasource()).getImageUrl(item.picture);
        if(view2Media != null){
            ImageLoader imageLoader = new PicassoImageLoader(view2.getContext(), false);
            imageLoader.load(imageLoaderRequest()
                                   .withPath(view2Media.toExternalForm())
                                   .withTargetView(view2)
                                   .fit()
                                   .build()
                    );
            
        } else {
            view2.setImageDrawable(null);
        }
        
        TextView view3 = (TextView) view.findViewById(R.id.view3);
        view3.setText((item.text3 != null ? item.text3 : ""));
        
    }

    @Override
    protected void onShow(SampleDSItem item) {
        // set the title for this fragment
        getActivity().setTitle("Sakib Kibria");
    }
}
