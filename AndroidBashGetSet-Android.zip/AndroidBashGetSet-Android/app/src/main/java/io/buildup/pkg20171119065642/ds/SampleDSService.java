
package io.buildup.pkg20171119065642.ds;
import java.net.URL;
import io.buildup.pkg20171119065642.R;
import buildup.ds.RestService;
import buildup.util.StringUtils;

/**
 * "SampleDSService" REST Service implementation
 */
public class SampleDSService extends RestService<SampleDSServiceRest>{

    public static SampleDSService getInstance(){
          return new SampleDSService();
    }

    private SampleDSService() {
        super(SampleDSServiceRest.class);

    }

    @Override
    public String getServerUrl() {
        return "https://pods.hivepod.io";
    }

    @Override
    protected String getApiKey() {
        return "ooE5t0vQ";
    }

    @Override
    public URL getImageUrl(String path){
        return StringUtils.parseUrl("https://pods.hivepod.io/app/5a112b29844e08040019a764",
                path,
                "apikey=ooE5t0vQ");
    }

}
